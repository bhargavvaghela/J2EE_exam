package com.cdac.rto.command;

import  com.cdac.rto.domain.User;

public class UserCommand {
    User user;


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    
}
